package org.example.student.dotsboxgame

/*
 * Direction enum
 * only 2 possible values
 */
enum class Direction {
    HORIZONTAL, VERTICAL
}